package com.mybusiness.inventoryapp;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import androidx.annotation.Nullable;

// Class to help make the logon process smoother for users.
// Not implemented (or finished) due to lack of time.
// #FIXME: Allow user to create account using provided credentials when attempting to "log in" instead of clicking create account
//
public class LoginFailedPopUp extends Activity {

    Button yes;
    Button no;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup_loginfailed);

        DisplayMetrics screenSize = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(screenSize);

        int width = screenSize.widthPixels;
        int height = screenSize.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .5));

        // Hide status and action bar
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        ActionBar actionBar = getActionBar();
        actionBar.hide();

        // Get the UI buttons
        yes = findViewById(R.id.yes_button);
        no = findViewById(R.id.no_button);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // #FIXME: Add username and password to database...

                // Start inventory activity
                startActivity(new Intent(LoginFailedPopUp.this, InventoryActivity.class));
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
