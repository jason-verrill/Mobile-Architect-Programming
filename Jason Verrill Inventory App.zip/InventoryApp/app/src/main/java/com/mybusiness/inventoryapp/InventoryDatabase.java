package com.mybusiness.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

// Class that tracks both accounts and inventory items in separate databases
public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String INVENTORY_DB = "inventory.db";
    private static final int VERSION = 2;
    private int userID;     // IMPORTANT for tracking who is currently logged in

    public InventoryDatabase(Context context) {
        super(context, INVENTORY_DB, null, VERSION);
    }

    // Table for items
    private static final class InventoryTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "id";
        private static final String COL_POSITION = "position";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_OWNER = "owner";
    }

    // Table for accounts
    private static final class AccountTable {
        private static final String TABLE = "accounts";
        private static final String COL_ID = "id";
        private static final String COL_USER = "user";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("DEBUGGING", "InventoryDatabase.onCreate() called");

        // Create tables
        db.execSQL("create table " + AccountTable.TABLE + " (" +
                AccountTable.COL_ID + " integer primary key autoincrement, " +
                AccountTable.COL_USER + " text, " +
                AccountTable.COL_PASSWORD + " text)");

        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key, " +
                InventoryTable.COL_POSITION + " integer, " +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_QUANTITY + " text, " +
                InventoryTable.COL_OWNER + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + AccountTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    // Get the total number of unique entries for a specific user's items (uses currently logged in userID)
    // Ex. User1 has 3 items, User2 has 8, etc...
    public int getSize() {
        // Query database
        // Gets all positions (arbitrary) from a userID, then counts them
        int size = 0;
        SQLiteDatabase db = getReadableDatabase();
        String query = "select position from " + InventoryTable.TABLE + " where owner = " + userID;

        Cursor cursor = db.rawQuery(query, null);

        // Count number of results
        if (cursor.moveToFirst()) {
            do {
                size++;
            }
            while (cursor.moveToNext());
        }

        return size;
    }

    // Used to attempt to log a user in
    // Checks username and password against database
    // Provides toasts to provide user with more info
    public int loginUser(String user, String password, Context context) {
        int id = -1;
        SQLiteDatabase db = getReadableDatabase();
        String queryUserPass = "select id from " + AccountTable.TABLE + " where user = ?" + " AND password = ?";
        Cursor cursorUserPass = db.rawQuery(queryUserPass, new String[] {user, password});

        // Username and password valid. Log in.
        if (cursorUserPass != null && cursorUserPass.moveToFirst()) {
            id = cursorUserPass.getInt(0);
            cursorUserPass.close();
            Log.d("DEBUGGING", "Log In: username and password match");
            return id;
        }
        else {
            Toast.makeText(context, "Username or password incorrect", Toast.LENGTH_LONG).show();
        }

        return id;
    }

    // Used to attempt to create a new user account
    // Checks username and password against database for existing username
    // Provides toasts to provide user with more info
    public int addUser(String user, String password, Context context) {
        int id = -1;
        SQLiteDatabase db = getWritableDatabase();
        String queryUserPass = "select id from " + AccountTable.TABLE + " where user = ?" + " AND password = ?";
        String queryUser = "select id from " + AccountTable.TABLE + " where user = ?";
        Cursor cursorUserPass = db.rawQuery(queryUserPass, new String[] {user, password});
        Cursor cursorUser = db.rawQuery(queryUser, new String[] {user});

        // Username and password both exist. Log in.
        if (cursorUserPass != null && cursorUserPass.moveToFirst()) {
            id = cursorUserPass.getInt(0);
            cursorUserPass.close();
            Toast.makeText(context, "username and password match", Toast.LENGTH_LONG).show();
            Log.d("DEBUGGING", "New User: username and password match");
            return id;
        }

        // Username exists but password is wrong. Don't log in.
        if (cursorUser != null && cursorUser.moveToFirst()) {
            cursorUser.close();
            Toast.makeText(context, "Username exists but password does not match.", Toast.LENGTH_LONG).show();
            Log.d("DEBUGGING", "username matches");
            return id;
        }

        // Username and password do not exist. Create account.
        Log.d("DEBUGGING", "username does not exist. creating new account");
        ContentValues values = new ContentValues();
        values.put(AccountTable.COL_USER, user);
        values.put(AccountTable.COL_PASSWORD, password);

        // Add account to the database
        db.insert(AccountTable.TABLE, null, values);

        // Lookup and return new userID
        String queryID = "select id from " + AccountTable.TABLE + " where user = ?";
        Cursor cursorID = db.rawQuery(queryID, new String[] {user});

        if (cursorID != null && cursorID.moveToFirst()) {
            id = cursorID.getInt(0);
        }

        Log.d("DEBUGGING", "New user ID created: " + id);
        return id;
    }

    // Add a new inventory item to the database
    public void addItem(String name, String quantity, int position) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_POSITION, position);
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_QUANTITY, quantity);
        values.put(InventoryTable.COL_OWNER, userID);

        long id = db.insert(InventoryTable.TABLE, null, values);
        Log.d("DEBUGGING", "Added " + name + " with id " + id);
    }

    // Removes an item from the database
    public void removeItem(int position) {
        SQLiteDatabase db = getWritableDatabase();

        db.delete(InventoryTable.TABLE, InventoryTable.COL_POSITION + " = ? AND owner = " + userID, new String[] {Integer.toString(position)});

        ContentValues values = new ContentValues();

        // Shift IDs to match position
        // This loop may be obsolete because it was made before creating a different column for id and position (they used to be used as the same thing)
        for (int i = position; i < getSize(); i++) {
            values.put(InventoryTable.COL_POSITION, i-1);
            db.update(InventoryTable.TABLE, values, "position = ?", new String[] {Integer.toString(position)});
        }

        Log.d("DEBUGGING", "Table size: " + getSize());
        listAll();
    }

    // Update an item
    // Ultimately used by InventoryActivity's increase, decrease, and edit functions
    public void updateItem(String name, String quantity, int position) {
        Log.d("DEBUGGING", "Updating database...");
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_POSITION, position);
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_QUANTITY, quantity);

        db.update(InventoryTable.TABLE, values, "position = ?", new String[] {Integer.toString(position)});
    }

    // Retrieves an item name provided the position in the inventoryList/database
    // This has bugs and can cause one account to be able to edit another account's items
    // #FIXME: Correct defect that allows one account to edit another's items
    public String getName(int position) {
        SQLiteDatabase db = getReadableDatabase();
        String name = "";
        String query = "select name from " + InventoryTable.TABLE + " where position = ? AND owner = " + userID;

        Cursor cursor = db.rawQuery(query, new String[] {Integer.toString(position)});

        if (cursor != null && cursor.moveToFirst()) {
            Log.d("DEBUGGING", "name: " + cursor.getString(0));
            name = cursor.getString(0);
        }

        cursor.close();

        return name;
    }

    // Retrieves an item's quantity provided the position in the inventoryList/database
    // This has bugs and can cause one account to be able to edit another account's items
    // #FIXME: Correct defect that allows one account to edit another's items
    public String getQuantity(int position) {
        SQLiteDatabase db = getReadableDatabase();
        String quantity = "";
        String query = "select quantity from " + InventoryTable.TABLE + " where position = ? AND owner = " + userID;

        Cursor cursor = db.rawQuery(query, new String[] {Integer.toString(position)});

        if (cursor != null && cursor.moveToFirst()) {
            Log.d("DEBUGGING", "quantity: " + cursor.getString(0));
            quantity = cursor.getString(0);
        }

        cursor.close();

        return quantity;
    }

    // Tell the database who is currently logged in
    public void setUserID(int userID) {
        this.userID = userID;
    }

    // Used for testing purposes
    public void eraseAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("drop table if exists " + AccountTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    // Used for testing purposes
    public void listAll() {
        for (int i = 1; i < getSize(); i++) {
            Log.d("DEBUGGING" , "Position: " + (i));
            Log.d("DEBUGGING" , "Name: " + getName(i));
            Log.d("DEBUGGING" , "Quantity: " + getQuantity(i));
        }
    }
}