package com.mybusiness.inventoryapp;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// UI window to create a new inventory item
public class NewItemActivity extends Activity {

    EditText itemName;
    EditText itemQuantity;
    String itemPosition = "";
    boolean hasData;

    Button createButton;
    Button cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

        Log.d("DEBUGGING", "NewItemActivity.onCreate() called");

        // Set activity screen size to look like a pop up window
        DisplayMetrics screenSize = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(screenSize);

        int width = screenSize.widthPixels;
        int height = screenSize.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .5));

        // Hide status and action bar
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        ActionBar actionBar = getActionBar();
        actionBar.hide();

        // Get UI views
        itemName = findViewById(R.id.edit_new_item_name);
        itemQuantity = findViewById(R.id.edit_new_item_quantity);
        createButton = findViewById(R.id.new_item_create);
        cancelButton = findViewById(R.id.new_item_cancel);

        // Get bundle data from existing holder if applicable
        // Fills in text fields with prior information
        Bundle bundleData = new Bundle();
        bundleData = getIntent().getExtras();
        hasData = false;

        if (bundleData != null) {
            itemName.setText(bundleData.getString("name"));
            itemQuantity.setText(bundleData.getString("quantity"));
            itemPosition = bundleData.getString("position");
            hasData = true;
        }

        // Set create callback
        createButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.d("DEBUGGING", "NewItemActivity.createButton.onClick() called");
                // Reduce clutter by storing calls in a shortcut
                String name = itemName.getText().toString();
                String quantity = itemQuantity.getText().toString();

                Intent createIntent = new Intent();

                // Validate Input
                if (name.isEmpty()) {
                    itemName.setError("Cannot be empty");
                }
                else {
                    // Set quantity to 0 if empty
                    if (quantity.isEmpty()) {
                        quantity = "0";
                    }

                    // Store values
                    createIntent.putExtra("name", name);
                    createIntent.putExtra("quantity", quantity);
                    createIntent.putExtra("position", itemPosition);
                    createIntent.putExtra("hasData", hasData);

                    setResult(RESULT_OK, createIntent);
                    finish();
                }
            }
        });

        // Set cancel callback
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}