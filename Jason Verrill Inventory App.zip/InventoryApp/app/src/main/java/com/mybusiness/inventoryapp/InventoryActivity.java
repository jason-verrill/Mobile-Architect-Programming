package com.mybusiness.inventoryapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class InventoryActivity extends AppCompatActivity {

    private int userID;     // This is the user currently logged in

    SettingsActivity settings;

    RecyclerView.LayoutManager layoutManager;
    RecyclerView recyclerView;
    RecyclerAdapter recyclerAdapter;

    Button newItem;
    Button settingsButtonActive;
    Button settingsButtonInactive;

    boolean hasSMS;

    public InventoryActivity() {
        settings = new SettingsActivity();
        hasSMS = false;
    }

    public RecyclerAdapter getRecyclerAdapter() {
        return recyclerAdapter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Hide status and action bar
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        // Store userID for database access
        userID = getIntent().getIntExtra("id", -1);
        Log.d("DEBUGGING", "User logged in: " + userID);

        // Create necessary views/manager for a swipable list UI
        layoutManager = new LinearLayoutManager(this);
        recyclerAdapter = new RecyclerAdapter(InventoryActivity.this);
        recyclerAdapter.setUserID(userID);

        recyclerView = findViewById(R.id.recycle_view);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerAdapter);

        // New item button handle and callback
        newItem = findViewById(R.id.create_new_item);

        newItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(InventoryActivity.this, NewItemActivity.class), 1);
            }
        });

        // Settings buttons for notification alerts
        // Both are in the exact same UI location, but is allowed to be toggled to effectively
        // change the icon. (not sure how to programmatically change the vector drawable?)
        settingsButtonActive = findViewById(R.id.settings_button_active);
        settingsButtonInactive = findViewById(R.id.settings_button_inactive);

        settingsButtonActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("DEBUGGING", "settings button clicked");
                startActivityForResult(new Intent(InventoryActivity.this, SettingsActivity.class), 2);
            }
        });

        settingsButtonInactive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("DEBUGGING", "settings button clicked");
                startActivityForResult(new Intent(InventoryActivity.this, SettingsActivity.class), 2);
            }
        });


    }

    // Refresh database on resume
    @Override
    public void onResume() {
        super.onResume();

        recyclerAdapter.loadDatabase();
    }

    // Pause override, not utilized anymore
    @Override
    public void onPause() {
        super.onPause();

        Log.d("DEBUGGING", "InventoryActivity.onPause() called");
    }

    // Send notification on low inventory
    // Originally thought this was the assignment so its not in use but its functional!
    public void sendLowInventoryNotification(String name, int position) {

        if (settings.getNotificationsEnabled()) {
            NotificationCompat.Builder alert = new NotificationCompat.Builder(this, "test notification");
            alert.setContentTitle("Out of Stock");
            alert.setContentText(name + " is out of stock!");
            alert.setSmallIcon(R.drawable.ic_baseline_not_interested_24);
            alert.setAutoCancel(true);

            NotificationManagerCompat alertManager = NotificationManagerCompat.from(this);
            alertManager.notify(position, alert.build());
        }
    }

    // Send SMS message on low inventory
    // Gets phone number from user's UI input
    public void sendLowInventorySMS(String name, int position) {

        if (settings.getNotificationsEnabled()) {

            Log.d("DEBUGGING", "Phone number: " + settings.getSMSNumber());
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(settings.getSMSNumber(), null, "Inventory item " + name + " is out of stock.", null, null);
        }
    }

    // Get SMS permissions
    private void getSMSPermission() {
        String SMSPermission = Manifest.permission.SEND_SMS;
        Log.d("DEBUGGING", "SMS Permission: " + SMSPermission);

        // Checks to see if permissions are already granted and whether additional explanation is necessary
        if (ContextCompat.checkSelfPermission(this, SMSPermission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, SMSPermission)) {

                ActivityCompat.requestPermissions(this, new String[] {SMSPermission}, 0);
                createAlertDialog("Permissions required", "Permissions are required to send SMS messages.");
            }
            else {
                createAlertDialog("Permissions required", "Permissions are explicitly denied for SMS messages. If you want SMS messages, please change phone settings.");
            }
        }
        else {
            // Tracks if notifications are allowed
            hasSMS = true;
        }
    }

    // Helper function to create a dialog box
    public void createAlertDialog(String title, String message) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage(message);
        alertBuilder.setTitle(title);
        alertBuilder.setCancelable(false);
        alertBuilder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alert = alertBuilder.create();
        alert.show();
    }

    // Called by RecyclerHolder child to start editing itself
    public void startEditActivity(String name, String quantity, String position) {
        Intent intent = new Intent(InventoryActivity.this, NewItemActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("quantity", quantity);
        intent.putExtra("position", position);

        startActivityForResult(intent, 1);
    }

    // Intent information received after a called activity has finished.
    // 3 active responses: creating a new item, editing an existing item, and one from settings
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        Log.d("DEBUGGING", "InventoryActivity.onActivityResult() called");

        if (resultCode == RESULT_OK) {

            // Response after creating or editing a RecyclerHolder child
            // Saves the name, quantity, and position to the database (by passing the information to the adapter first)
            if (requestCode == 1) {
                Log.d("DEBUGGING", "Request code was 1");

                String itemName = intent.getStringExtra("name");
                String itemQuantity = intent.getStringExtra("quantity");
                String position = "";
                boolean hasData = intent.getBooleanExtra("hasData", false);

                if (hasData) {
                    position = intent.getStringExtra("position");
                    recyclerAdapter.updateItem(itemName, itemQuantity, Integer.valueOf(position));
                } else {
                    recyclerAdapter.addItem(itemName, itemQuantity);
                }

                recyclerAdapter.notifyDataSetChanged();

            }
            // Response from settings for phone number and whether notifications are enabled or not
            else if (requestCode == 2) {

                Log.d("DEBUGGING", "Request code was 2");

                settings.setSMSNumber(intent.getStringExtra("number"));
                boolean enable = intent.getBooleanExtra("enable", false);
                Log.d("DEBUGGING", "Enable: " + enable);

                settings.setNotificationsEnabled(enable);

                // Effectively changes the settings icon by swapping visible buttons
                if (enable) {
                    if (hasSMS) {
                        settingsButtonActive.setVisibility(View.VISIBLE);
                        settingsButtonInactive.setVisibility(View.GONE);
                    }
                    else {
                        getSMSPermission();
                        settingsButtonActive.setVisibility(View.VISIBLE);
                        settingsButtonInactive.setVisibility(View.GONE);
                    }
                }
                else {
                    settingsButtonActive.setVisibility(View.GONE);
                    settingsButtonInactive.setVisibility(View.VISIBLE);
                }
            }
            else {
                Log.d("DEBUGGING", "result code invalid");
            }
        }
    }
}