package com.mybusiness.inventoryapp;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

// Data that holds a single item's information
public class RecyclerHolder extends RecyclerView.ViewHolder {

    RecyclerAdapter parentAdapter;

    TextView itemNameView;
    TextView itemQuantityView;
    TextView itemPosition;
    Button editButton;
    Button deleteButton;
    Button decreaseButton;
    Button increaseButton;

    int position;

    public RecyclerHolder(final View parent, RecyclerAdapter parentAdapter) {
        super(parent);

        this.parentAdapter = parentAdapter;

        // Get layout views
        itemNameView = parent.findViewById(R.id.item_name);
        itemQuantityView = parent.findViewById(R.id.item_quantity);
        itemPosition = parent.findViewById(R.id.item_position);
        editButton = parent.findViewById(R.id.item_edit);
        deleteButton = parent.findViewById(R.id.item_delete);
        decreaseButton = parent.findViewById(R.id.item_decrease);
        increaseButton = parent.findViewById(R.id.item_increase);

        // Edit button callback
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = itemNameView.getText().toString();
                String quantity = itemQuantityView.getText().toString().substring(2);
                String position = itemPosition.getText().toString();

                parentAdapter.editItem(name, quantity, position);
            }
        });

        // Delete button callback
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parentAdapter.removeItem(getAdapterPosition());
            }
        });

        // Decrease button callback
        decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parentAdapter.decreaseItem(getAdapterPosition());
            }
        });

        // Increase button callback
        increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parentAdapter.increaseItem(getAdapterPosition());
            }
        });
    }
}