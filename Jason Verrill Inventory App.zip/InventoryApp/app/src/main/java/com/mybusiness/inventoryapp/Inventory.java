package com.mybusiness.inventoryapp;

public class Inventory {
    String name;
    String quantity;
    int position;
    int id;

    Inventory(String itemName, String startingQuantity, int position) {
        name = itemName;
        quantity = startingQuantity;
        this.position = position;
    }

    Inventory(String itemName, String startingQuantity, int position, int id) {
        name = itemName;
        quantity = startingQuantity;
        this.position = position;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String itemQuantity) {
        quantity = itemQuantity;
    }

    public void decreaseQuantity() {
        int amount = Integer.valueOf(quantity);

        if (amount != 0) {
            amount--;
        }

        quantity = Integer.toString(amount);
    }

    public void increaseQuantity() {
        int amount = Integer.valueOf(quantity);
        amount++;

        quantity = Integer.toString(amount);
    }
}