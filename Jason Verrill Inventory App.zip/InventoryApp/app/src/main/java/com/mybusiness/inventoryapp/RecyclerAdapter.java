package com.mybusiness.inventoryapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// I used the adapter as my swiss army knife to facilitate communication between activities
// Holds active inventory list and the database
public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerHolder>{

    InventoryActivity parentActivity;
    ArrayList<Inventory> inventoryList;
    InventoryDatabase database;
    int userID;

    public RecyclerAdapter(InventoryActivity parentActivity) {
        this.parentActivity = parentActivity;
        inventoryList = new ArrayList<Inventory>();
        database = new InventoryDatabase(parentActivity.getApplicationContext());
    }

    // Create UI elements for new holder
    @Override
    public RecyclerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item, parent, false);
        RecyclerHolder newHolder = new RecyclerHolder(view, this);

        return newHolder;
    }

    // Fill holder with data
    @Override
    public void onBindViewHolder(RecyclerHolder holder, int position) {
        holder.itemNameView.setText(inventoryList.get(position).getName());
        holder.itemQuantityView.setText("x " + inventoryList.get(position).getQuantity());
        holder.itemPosition.setText(Integer.toString(position));
    }

    // Get the number of active items
    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    // Edit an item's data
    public void editItem(String name, String quantity, String position) {

        parentActivity.startEditActivity(name, quantity, position);
    }

    // Load or reload the inventory list from the database
    public void loadDatabase() {
        // Get size of database
        database.setUserID(userID);
        Log.d("DEBUGGING", "Loading from database...");
        int size = database.getSize();
        Log.d("DEBUGGING", "Database has " + size + " items to load.");

        // Empty inventory list
        inventoryList.clear();
        //database.eraseAll();

        // Fill inventory list from database
        // This calls the getName() and getQuantity()
        // Either i is off or the called functions are (this is buggy)
        // #FIXME: Verify iterator i and called functions getName() and getQuantity()
        for (int i = 0; i < size; i++) {
            Log.d("DEBUGGING", "Loading item position " + (i) + " from database");
            inventoryList.add(new Inventory(database.getName(i), database.getQuantity(i), i));
        }

        notifyDataSetChanged();
    }

    // Save data from inventory list to the database
    public void saveDatabase() {
        Log.d("DEBUGGING", "Saving the database...");

        for (int i = 0; i < inventoryList.size(); i++) {
            Log.d("DEBUGGING", "Saving " + inventoryList.get(i).getName() + ", " + inventoryList.get(i).getQuantity());
            database.updateItem(inventoryList.get(i).getName(), inventoryList.get(i).getQuantity(), i);
        }
    }

    // Add an item to database
    public void addItem(String itemName, String itemQuantity) {
        database.addItem(itemName, itemQuantity, inventoryList.size());
        Inventory newItem = new Inventory(itemName, itemQuantity, inventoryList.size());

        //inventoryList.add(newItem);
        notifyDataSetChanged();
    }

    // Update item in inventory list and database
    public void updateItem(String itemName, String itemQuantity, int position) {
        inventoryList.get(position).setName(itemName);
        inventoryList.get(position).setQuantity(itemQuantity);
        notifyDataSetChanged();

        database.updateItem(itemName, itemQuantity, position);
    }

    // Remove item from inventory list and database
    public void removeItem(int position) {
        inventoryList.remove(position);
        notifyDataSetChanged();

        database.removeItem(position);
    }

    // Decrease an item's quantity identified by position in inventory list
    protected void decreaseItem(int position) {
        inventoryList.get(position).decreaseQuantity();
        notifyDataSetChanged();

        // Send low inventory alert notification if quantity reaches 0
        if (inventoryList.get(position).getQuantity().equals("0")) {
            String name = inventoryList.get(position).getName();
            parentActivity.sendLowInventorySMS(inventoryList.get(position).getName(), position);
        }

        int quantity = Integer.valueOf(inventoryList.get(position).getQuantity());

        database.updateItem(inventoryList.get(position).getName(), Integer.toString(quantity), position);
    }

    // Increase an item's quantity identified by position in inventory list
    protected void increaseItem(int position) {
        inventoryList.get(position).increaseQuantity();
        notifyDataSetChanged();

        int quantity = Integer.valueOf(inventoryList.get(position).getQuantity());

        database.updateItem(inventoryList.get(position).getName(), Integer.toString(quantity), position);
    }

    // Sets the currently logged in userID
    protected void setUserID(int userID) {
        this.userID = userID;
    }
}