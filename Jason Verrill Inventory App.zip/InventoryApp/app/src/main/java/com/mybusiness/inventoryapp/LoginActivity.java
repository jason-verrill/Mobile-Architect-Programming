package com.mybusiness.inventoryapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// Login Activity - Initial starting activity for logging in
public class LoginActivity extends AppCompatActivity {

    public InventoryDatabase accountDatabase;

    EditText userText;
    EditText passwordText;

    Button loginButton;
    Button createAccountButton;

    // Initial setup when created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d("DEBUGGING", "LoginActivity.onCreate() called");

        setContentView(R.layout.activity_login);

        // Hide status and action bar
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        // Create database for accounts
        Log.d("DEBUGGING", "Creating account database...");
        accountDatabase = new InventoryDatabase(getApplicationContext());

        // Get handles to views
        userText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Assign clickback function for login button
        // Checks that username and password are in the database
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = userText.getText().toString().toLowerCase();
                String password = passwordText.getText().toString().toLowerCase();

                // For testing purposes to start databases over to clean out ghost entries
                //accountDatabase.eraseAll();

                // If username or password field is empty, display a simple error prompt
                if (username.isEmpty()) {
                    userText.setError("Please enter a username");
                }
                else if (password.isEmpty()) {
                    passwordText.setError("Please enter a password");
                }
                else {
                    // Attempt to log into the database
                    // Returns the userID if successful and -1 if not
                    int userID = accountDatabase.loginUser(username, password, getApplicationContext());

                    if (userID != -1) {
                        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                        intent.putExtra("id", userID);

                        startActivity(intent);
                    }
                }

                // Not implemented due to lack of time
                //Intent intent = new Intent(LoginActivity.this, LoginFailedPopUp.class);
                //startActivity(intent);
            }
        });

        // Assign clickback function for create account button
        // The main difference from login button is that if neither username nor password exist,
        // it will create an account. Cannot create an account if it finds a matching username but incorrect password,
        // but will create an account if username and password happen to both exist and match for convenience
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get username and password
                // Ignore capitalization
                String username = userText.getText().toString().toLowerCase();
                String password = passwordText.getText().toString().toLowerCase();

                // If username or password field is empty, display a simple error prompt
                if (username.isEmpty()) {
                    userText.setError("Please enter a username");
                }
                else if (password.isEmpty()) {
                    passwordText.setError("Please enter a password");
                }
                else {
                    // Attempt to log into the database
                    // Returns the userID if successful and -1 if not
                    int userID = accountDatabase.addUser(username, password, getApplicationContext());

                    if (userID != -1) {
                        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                        intent.putExtra("id", userID);

                        startActivity(intent);
                    }
                    else {
                        Log.d("DEBUGGING", "Logon credentials invalid");
                    }
                }
            }
        });
    }
}