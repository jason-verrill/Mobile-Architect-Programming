package com.mybusiness.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// Setting to allow or not allow SMS messages when inventory reaches 0
// Defaults to not allow. Permission request is handled elsewhere but this passes the info along
public class SettingsActivity extends AppCompatActivity {

    Button yes;
    Button no;

    EditText phoneNumber;

    String SMSNumber;
    private boolean notificationsEnabled ;

    public SettingsActivity() {
        notificationsEnabled = false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Log.d("DEBBUGGING", "SettingsActivity.onCreate() called");

        // Hide status and action bar
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        // #FIXME: actionBar keeps evaluating to null and background is not dimmed?
        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        // Set activity dimensions to look like a pop up window
        DisplayMetrics screenSize = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(screenSize);

        int width = screenSize.widthPixels;
        int height = screenSize.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .8));

        phoneNumber = findViewById(R.id.phone_number);

        yes = findViewById(R.id.settings_yes_button);

        // Yes button callback
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SMSNumber = phoneNumber.getText().toString();

                // Phone number cannot be empty, and must be either 7 or 10 digits long
                if (SMSNumber.isEmpty() || (SMSNumber.length() != 7 && SMSNumber.length() != 10)) {
                    phoneNumber.setError("Invalid phone number");
                }
                else {
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("enable", true);
                    returnIntent.putExtra("number", SMSNumber);
                    setResult(RESULT_OK, returnIntent);

                    // return data and settings back
                    finish();
                }
            }
        });

        no = findViewById(R.id.settings_no_button);

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                returnIntent.putExtra("enable", false);
                setResult(RESULT_OK, returnIntent);

                finish();
            }
        });
    }

    public void setNotificationsEnabled(boolean enable) {
        notificationsEnabled = enable;
    }
    public boolean getNotificationsEnabled() {
        return notificationsEnabled;
    }
    public String getSMSNumber() {
        return SMSNumber;
    }

    public void setSMSNumber(String number) {
        SMSNumber = number;
    }
}